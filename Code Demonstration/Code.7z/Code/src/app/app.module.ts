import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PhotoComponent } from './photo/photo.component';
import { GalleryComponent } from './gallery/gallery.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { HttpClientModule, HttpClient, HttpHandler } from '@angular/common/http';
import { NgxSpinnerModule } from "ngx-spinner";
import { ConvertImageToTextComponent } from './convert-image-to-text/convert-image-to-text.component';

@NgModule({
  declarations: [
    AppComponent,
    PhotoComponent,
    GalleryComponent,
    UploadImageComponent,
    ConvertImageToTextComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    NgxSpinnerModule,
    HttpClientModule

  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
