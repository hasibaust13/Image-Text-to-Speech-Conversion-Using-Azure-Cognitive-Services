import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { TrainUserCommand } from './models/trainUser';
import { Observable, of, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { TestImageCommand } from './models/testImageCommand';
import { ConvertTextToSpeechCommand } from './models/convertTextToSpeechCommand';
import { ReadTextFromImageCommand } from './models/readTextFromImageCommand';
@Injectable({
  providedIn: 'root',
})
export class TrainingService {
  constructor(private http: HttpClient) {}
  uploadFiles(filesToBeUploaded: FileList) {

     // const endpoint = 'http://localhost/autoTagger/api/photo/uploadImageWithoutRecord';
     const endpoint = 'http://localhost:7071/api/TestUpload';
    const formData: FormData = new FormData();
    for (let i = 0; i < filesToBeUploaded.length; i++) {
      formData.append(
        'images',
        filesToBeUploaded[i],
        filesToBeUploaded[i].name
      );
    }
    return this.http.post(endpoint, formData)
    //  .pipe(map(map((data: any) => data)))
    ;
  }

  convertImageToText(url: string){
    const endpoint = 'http://localhost:7071/api/readTextFromImage';
    let command=new ReadTextFromImageCommand();
    command.Url=url;
    return this.http.post(endpoint,command);
  }

  convertTextToSpeech(text: string){
    const endpoint = 'http://localhost:7071/api/convertTextToSpeech';
    let command = new ConvertTextToSpeechCommand();
    command.Text=text;
    return this.http.post(endpoint,command);


  }

  trainWithUrlList(urlList:string[], names:string[], groupGuid:string=null){
    const endpoint='http://localhost:7071/api/TrainIndependentDataWithGroupPhotos';
    let command = new TrainUserCommand();
    command.Names = names;
    command.Urls = urlList;
    command.PersonGroupGuid=groupGuid;
    return this.http.post(endpoint,command);
  }

  testImageWithList(urlList:string[], personGroupGuid:string){
    const endpoint='http://localhost:7071/api/TestIndependentTags';
    let command=new TestImageCommand();
    command.Urls=urlList;
    command.personGroupGuid=personGroupGuid;
    return this.http.post(endpoint,command);
  }
}
