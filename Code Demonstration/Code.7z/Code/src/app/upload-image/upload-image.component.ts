import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../training.service';
import { NgForm } from '@angular/forms';
import { TrainingInformation } from '../models/trainingInformation';
import { TestImageResult, Result } from '../models/testImageResult';
import { ResultDisplay } from '../models/resultDisplay';
import { NgxSpinnerService } from "ngx-spinner";
import { ConvertTextToSpeechResult } from '../models/convertTextToSpeechResult';

@Component({
  selector: "app-upload-image",
  templateUrl: "./upload-image.component.html",
  styleUrls: ["./upload-image.component.css"],
  providers: [TrainingService],
})
export class UploadImageComponent implements OnInit {
  filesToBeUploaded: FileList = null;
  filesToBeTested: FileList = null;
  personGroupGuid: string = null;
  faceResults: Result[] = null;
  displayResults: ResultDisplay[] = null;
  trainImagesUploaded = false;
  testImagesUploaded = false;
  resultAudioFileLocation = '';
  faceNames: string[]= [];
  imageUrl: string = "https://www.tibs.org.tw/images/default.jpg";

  constructor(
    private trainingService: TrainingService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {}

  OnSubmit(test: NgForm) {
    this.spinner.show();
    const tags: string = test.controls.tags.value;
    const names = tags.split(";");

    console.log(names);
    console.log(tags);
    this.trainingService.uploadFiles(this.filesToBeUploaded).subscribe(
      (data) => {
        console.log(data);
        this.trainDataWithUrlList(data as string[], names);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  OnSubmitTestImage(form: NgForm) {
    this.spinner.show();

    this.trainingService.uploadFiles(this.filesToBeTested).subscribe(
      (data) => {
        console.log(data);
        this.testDataWithUrlList(data as string[]);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  trainDataWithUrlList(urls: string[], names: string[]) {
    this.trainingService
      .trainWithUrlList(urls, names, this.personGroupGuid)
      .subscribe(
        (data) => {
          const response = data as TrainingInformation;
          this.personGroupGuid = response.personGroupGuid;
          console.log("personGroup Guid:" + this.personGroupGuid);
          this.spinner.hide();
        },
        (error) => {
          console.log(error);
          this.spinner.hide();
        }
      );
  }

  playSound(){
    console.log("HEY THERE!");
    let audio = new Audio();
    audio.src = this.resultAudioFileLocation;
    audio.load();
    audio.play();
  }

  testDataWithUrlList(urls: string[]) {
    this.trainingService
      .testImageWithList(urls, this.personGroupGuid)
      .subscribe(
        (data) => {
          const response = data as TestImageResult[];
          this.faceNames=response[0].uniqueFaceNames;
          debugger;
          this.faceResults = response[0].results;
          this.displayResults = this.convertFaceResultToDisplayResult(
            this.faceResults,
            response[0].url
          );
          this.spinner.hide();
          if(this.faceNames.length>0) {
            this.convertResultToSpeech(this.faceResults);
          } else{
            this.resultAudioFileLocation='';
          }
          console.log(this.displayResults);
        },
        (error) => {
          console.log(error);
          this.spinner.hide();
        }
      );
  }

  getCaptionText(): string {
    var str=this.faceNames.join(', ');
    console.log(str);
    return str;
  }

  convertResultToSpeech(result: Result[]){
    this.trainingService.convertTextToSpeech(this.getCaptionText())
    .subscribe(
      (data) => {
        const response = data as ConvertTextToSpeechResult;
        this.resultAudioFileLocation = response.url as string;
        console.log(this.resultAudioFileLocation);
      },
      (error) => {
        console.log(error);
        //this.spinner.hide();
      }
    );
  }

  handleFileInput(files: FileList) {
    // console.log(this.caption);
    if (files.length === 0) {
      this.trainImagesUploaded = false;
      return;
    }
    this.trainImagesUploaded = true;
    this.filesToBeUploaded = files;
  }

  handleTestFileInput(files: FileList) {
    // console.log(this.caption);
    this.filesToBeTested = files;
    if (files.length === 0) {
      this.testImagesUploaded = false;
      return;
    }
    this.testImagesUploaded = true;

    let file = files.item(0);
    var reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
    reader.readAsDataURL(file);
  }

  convertFaceResultToDisplayResult(faceResults: Result[], url: string) {
    var displayResults: ResultDisplay[] = [];
    faceResults.forEach((faceResult) => {
      faceResult.candidates.forEach((candidate) => {
        let result = new ResultDisplay();
        result.confidanceLevel = candidate.confidance;
        result.person = candidate.person;
        result.face = faceResult.face;
        result.imageUrl = url;
        displayResults.push(result);
      });
    });
    return displayResults;
  }
}
