export class TrainUserCommand {
  Urls: string[];
  Names: string[];
  PersonGroupGuid: string;
}
