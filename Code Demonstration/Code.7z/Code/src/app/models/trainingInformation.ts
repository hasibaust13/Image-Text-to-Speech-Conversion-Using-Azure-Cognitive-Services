export class TrainingInformation{
    personGroupGuid:string;
}