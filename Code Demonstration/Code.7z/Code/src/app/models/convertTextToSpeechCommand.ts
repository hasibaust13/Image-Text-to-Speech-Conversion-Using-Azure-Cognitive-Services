export class ConvertTextToSpeechCommand {
    Text: string;
  }
  