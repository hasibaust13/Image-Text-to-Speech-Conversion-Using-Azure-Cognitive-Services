    export class TestImageCommand {
        Urls: string[];
        personGroupGuid: string;
    }