export class ConvertTextToSpeechResult {
    url: string;
  }
