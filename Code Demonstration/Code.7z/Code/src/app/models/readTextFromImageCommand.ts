export class ReadTextFromImageCommand {
    Url: string;
  }
  