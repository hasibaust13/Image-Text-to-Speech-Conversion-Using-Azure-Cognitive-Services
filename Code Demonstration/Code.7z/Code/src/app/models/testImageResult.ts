export class FaceRectangle {
    width: number;
    height: number;
    left: number;
    top: number;
}

export class Face {
    faceId: string;
    recognitionModel: string;
    faceRectangle: FaceRectangle;
    //faceLandmarks?: any;
    //faceAttributes?: any;
}

export class Person {
    personId: string;
    //persistedFaceIds?: any;
    name: string;
    userData: string;
}

export class Candidate {
    person: Person;
    confidance: number;
}

export class Result {
    face: Face;
    candidates: Candidate[];
}

export class TestImageResult {
    url: string;
    results: Result[];
    uniqueFaceNames: string[];
}
