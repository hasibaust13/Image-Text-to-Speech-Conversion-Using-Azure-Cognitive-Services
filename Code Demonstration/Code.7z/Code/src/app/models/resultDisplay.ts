import { Person, Face } from './testImageResult';

export class ResultDisplay {
  person: Person;
  face: Face;
  confidanceLevel: number;
  imageUrl: string;
}
