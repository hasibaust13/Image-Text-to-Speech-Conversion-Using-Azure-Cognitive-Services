import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConvertImageToTextComponent } from './convert-image-to-text/convert-image-to-text.component';
import { UploadImageComponent } from './upload-image/upload-image.component';

const routes: Routes = [
  {
    path : '',
    component : UploadImageComponent
  },
  {
    path : 'image-to-speech',
    component : ConvertImageToTextComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
