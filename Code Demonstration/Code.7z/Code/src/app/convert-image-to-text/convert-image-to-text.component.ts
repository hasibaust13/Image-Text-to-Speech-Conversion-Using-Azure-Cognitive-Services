import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ConvertTextToSpeechResult } from '../models/convertTextToSpeechResult';
import { TrainingService } from '../training.service';

@Component({
  selector: 'app-convert-image-to-text',
  templateUrl: './convert-image-to-text.component.html',
  styleUrls: ['./convert-image-to-text.component.css']
})
export class ConvertImageToTextComponent implements OnInit {
  filesToBeTested: FileList = null;
  testImagesUploaded = false;
  imageUrl: string = "https://www.tibs.org.tw/images/default.jpg";
  imageText = '';
  resultAudioFileLocation = '';
    
    constructor(private spinner: NgxSpinnerService, private trainingService: TrainingService) { }

  ngOnInit() {
  }

  handleTestFileInput(files: FileList) {
    // console.log(this.caption);
    this.filesToBeTested = files;
    if (files.length === 0) {
      this.testImagesUploaded = false;
      return;
    }
    this.testImagesUploaded = true;

    let file = files.item(0);
    var reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
    reader.readAsDataURL(file);
  }

  OnSubmitTestImage(form: NgForm) {
    this.spinner.show();
  this.imageText = '';
    this.trainingService.uploadFiles(this.filesToBeTested).subscribe(
      (data) => {
        console.log(data);
        this.convertImageToText(data[0] as string);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  convertImageToText(url: string) {
    this.trainingService.convertImageToText(url).subscribe(
      (data) => {
        console.log(data);
        this.convertLinesToSpeechText(data as string[]);
        this.convertTextToSpeech();
        this.spinner.hide();
      },
      (error) => {
        console.log(error);
      }
    );
  }

  convertLinesToSpeechText(lines: string[]) {
    this.imageText = lines.join('\n');
  }

  playSound(){
    let audio = new Audio();
    audio.src = this.resultAudioFileLocation;
    audio.load();
    audio.play();
  }

  convertTextToSpeech() {
    this.trainingService.convertTextToSpeech(this.imageText)
    .subscribe(
      (data) => {
        const response = data as ConvertTextToSpeechResult;
        this.resultAudioFileLocation = response.url as string;
        console.log(this.resultAudioFileLocation);
      },
      (error) => {
        console.log(error);
        this.spinner.hide();
      }
    );
  }


}
