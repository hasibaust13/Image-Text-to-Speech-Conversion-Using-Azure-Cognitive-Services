import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {
  public galleryUrls=["https://ppfileserver.blob.core.windows.net/test-images/1593582929__FM_1.jpg","https://ppfileserver.blob.core.windows.net/test-images/1593587183___-txCzhBUU4.jpg"];
  constructor() {

   }

  ngOnInit() {
  }

}
